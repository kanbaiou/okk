import torch
from torch.autograd import Variable

from visualize import make_dot 

from baselinemodel import resnet20

import argparse 

from graphviz import Digraph

parser = argparse.ArgumentParser(description='setting for path and type for model file ')

parser.add_argument('--path', default='', type= str, metavar='PATH',
                    help='path to pytorch model')

parser.add_argument('--type', default='', type = str, metavar='TYPE',
                    help='type of model files, decice how to load the model')


args = parser.parse_args() 


if args.type == 'parametersonly':
   model_1 = resnet20()
   model_1.load_state_dict(torch.load(args.path))

else:

  model_1 = torch.load(args.path)

model_1 = model_1.cpu()


x = Variable(torch.randn(128,3,32,32))   

y = model_1(x)

g = make_dot(y)

g.view()



