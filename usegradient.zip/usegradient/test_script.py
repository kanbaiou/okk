import torch
import torchvision
from testnet import TestNet

class MyScriptModule(torch.nn.Module):
    def __init__(self):
        super(MyScriptModule, self).__init__()
        self.means = torch.nn.Parameter(torch.tensor([103.939, 116.779, 123.68])
                                        .resize_(1, 3, 1, 1))
        self.resnet = torch.jit.trace(torchvision.models.resnet18(),
                                      torch.rand(1, 3, 224, 224))

    def forward(self, input):
        return self.resnet(input - self.means)




net = TestNet()
class TestModule(torch.nn.Module):
    def __init__(self):
        super(TestModule, self).__init__()
        
        self.testnet = torch.jit.trace(net,
                                      torch.zeros(10,3,32,32))

    def forward(self, input):
        return self.testnet(input)