


### make all  father_node  to a  directional-graph

###  expand the graph  to two directional-graph

###  from these two graphs to generated the correct new network forward computing graph



##### how to..?
    

        ###  define basic rule    
        ###  basic rule 1  
                each node will be usd once and only  once
        ###  basic rule2
                if this node 's next node is more than two , this node should be saved
        
        ###  basic  rule 3
               if this node  's input node is more than two, this node should wait for all the node  
   
   
   
#### as a result ?  the most normal methods ( for all the use-case)?


      ####Pseudo code:
       
        initialize :
           in_stack
           in_value_stack
           out_stack
           out_value_stack
           start_node

           directional graph ( which node should know the input and output node to it)

        begin:
           if node 's output node is only one:
                computing  output
                goto next node
           else:
                computing the output
                goto next_node[0]
                set node[currentnode] as 0
                in_stack.push(node)
                in_value_stack.push(output)
        ----------- next_node is next_node or next_node[0]------------------------------    
        
           if  next_node 's input node is more than one:
                 set next_node(current_node) as  0   ### delete current node in next_node 's input node parts
                 
                 out_value_stack.push(output)  ### and also push the output to stack (will be used later)
                   
                 new_start_node = in_stack.pop()  ### reach one route's end , should start another route  
                 
                      goto new_start_node.next_node[0]
                      computing output
                      set next_node[current_node] as 0
                      if   new_start_node.next_node == [0,0,0.....]:    ### if all the next route is accessed
                               pass  ## this node will not be used again
                      else: 
                             in_stack.push(new_start_node)   ## will be used again 
            
          
           if    0 in next_node 's input_node:
                   set next_node[current_node ] as  0 
                   if next_node's input_node only contains 0 ### it's time to compute the next node
                           input_number =  len(next_node.input_node) 
                           out_value_stack.pop()  ##  pop input_number times 
                           next_node(out_value_stack's output)    


                    
                     
                  



             
                
                 


           
       
        　　  
