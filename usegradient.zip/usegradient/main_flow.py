from utils import *
from utils_2 import *
import torch 
import torch.nn as nn
from densenet import DenseNet121

test_input = torch.zeros(10,3,32,32)
baseline_model = DenseNet121()
target_conv, target_bn = get_conv_and_bn(baseline_model)

## define  the target-layer for the baseline_model
for  conv_layer,bn_layer in zip(target_conv,target_bn):
    conv_layer.weight.data = conv_layer.weight.data*0 ### replace
    conv_layer.weight.data[0,0,0,0] = target_conv.index(conv_layer)/100
    bn_layer.weight.data = bn_layer.weight.data*0
    bn_layer.weight.data[0] = target_bn.index(bn_layer)/100

##  recording  info in  every target layer's weight

####  starting to make the node-graph
output = baseline_model(test_input)
start_node = output.grad_fn

net_graph,end_node = generate_network_graph(start_node)

len_list =[]

for  v in net_graph.values():
    len_list.append(len(v)) 

len_list_after_expand = []

expand_graph(net_graph)

for v in net_graph.values():
     len_list_after_expand.append(len(v))

len_list_expand = list(map(lambda x,y :x-y,len_list_after_expand,len_list ))

sharing_node =[]

for k in net_graph.keys():
    if len(net_graph[k]) >=3:  ## if connnected with  more tha two nodes
        sharing_node.append(k)

reverse_graph(net_graph,len_list)

route =  search_N_route(net_graph,end_node,start_node,1)[0]
### search one node for the route  NOTE the start node and end_node is reversed

final_route =[end_node]  ### the final_route will start from the end_node 
for node in route:
    if node in sharing_node:
        final_route.append(node)
final_route.append(start_node)   ## get the final_route

print(final_route)
### get all  node 's type
key_list = list(net_graph.keys())
name_list =  list(map(lambda x:get_backward_name(x) , key_list))
### name_list is used to define how many type shoulde be dealed




class graph_network(nn.Module):

    def __init__(self,):
        super(graph_network,self).__init__()
        pass   






    def forward(self,x):

        pass







  









   











