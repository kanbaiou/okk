import torch
import re






TARGET_OP = {
    'aten::addmm': 'nn.Linear',
    'aten::_convolution': 'nn.Conv',
}

def is_maindataflow(node):
    if re.search(r'%[^0-9]+(\.[0-9]+)?[, ]', str(node)):
        return True
    return False

def operation_of(node):
    op = node.kind()
    if op in TARGET_OP:
        op = TARGET_OP[op]
    return op

def generate_module_graph(model, example_input):
    output = torch.jit.trace(model, example_input)
    trace = output.graph
    # print('--all trace--')
    # print(trace)
    for node in trace.nodes():
        if is_maindataflow(node):
            print('* {} @ {}'.format(operation_of(node), node.scopeName()))
            print('Detail: ' + str(node).rstrip())
            for i in node.inputs():
                if is_maindataflow(i.node()):
                    # Can be traced recursively
                    print('\t* In : ' + str(i.node()).rstrip())
            # Output is same of current node.
            # for i in node.outputs():
            #     if is_maindataflow(i.node()):
            #         print('\t* Out: ' + str(i.node()).rstrip())
    return trace

"""
* nn.Conv @ Net/Conv2d[conv1]
   Detail: %36 : Float(64, 10, 24, 24) = aten::_convolution(%input.1, %weight.1, %3, %21, %24, %27, %28, %31, %32, %33, %34, %35), scope: Net/Conv2d[conv1] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/modules/conv.py:340:0
        * In : %self : ClassType<Net>, %input.1 : Float(64, 1, 28, 28) = prim::Param()
        * In : %weight.1 : Tensor = prim::GetAttr[name="weight"](%1)
* nn.Conv @ Net/ChildNet[cn]/Conv2d[conva]
    Detail: %54 : Float(64, 10, 24, 24) = aten::_convolution(%input.1, %weight.2, %17, %39, %42, %45, %46, %49, %50, %51, %52, %53), scope: Net/ChildNet[cn]/Conv2d[conva] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/modules/conv.py:340:0
        * In : %self : ClassType<Net>, %input.1 : Float(64, 1, 28, 28) = prim::Param()
        * In : %weight.2 : Tensor = prim::GetAttr[name="weight"](%15)
* aten::add @ Net
    Detail: %input.2 : Float(64, 10, 24, 24) = aten::add(%36, %54, %55), scope: Net # ./main.py:28:0
        * In : %36 : Float(64, 10, 24, 24) = aten::_convolution(%input.1, %weight.1, %3, %21, %24, %27, %28, %31, %32, %33, %34, %35), scope: Net/Conv2d[conv1] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/modules/conv.py:340:0
        * In : %54 : Float(64, 10, 24, 24) = aten::_convolution(%input.1, %weight.2, %17, %39, %42, %45, %46, %49, %50, %51, %52, %53), scope: Net/ChildNet[cn]/Conv2d[conva] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/modules/conv.py:340:0
* aten::max_pool2d @ Net
    Detail: %input.3 : Float(64, 10, 12, 12) = aten::max_pool2d(%input.2, %59, %60, %63, %66, %67), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:487:0
        * In : %input.2 : Float(64, 10, 24, 24) = aten::add(%36, %54, %55), scope: Net # ./main.py:28:0
* aten::relu @ Net
    Detail: %input.4 : Float(64, 10, 12, 12) = aten::relu(%input.3), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:913:0
        * In : %input.3 : Float(64, 10, 12, 12) = aten::max_pool2d(%input.2, %59, %60, %63, %66, %67), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:487:0
* nn.Conv @ Net/Conv2d[conv2]
    Detail: %input.5 : Float(64, 20, 8, 8) = aten::_convolution(%input.4, %weight.3, %6, %72, %75, %78, %79, %82, %83, %84, %85, %86), scope: Net/Conv2d[conv2] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/modules/conv.py:340:0
        * In : %input.4 : Float(64, 10, 12, 12) = aten::relu(%input.3), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:913:0
        * In : %weight.3 : Tensor = prim::GetAttr[name="weight"](%4)
* aten::feature_dropout @ Net/Dropout2d[conv2_drop]
    Detail: %input.6 : Float(64, 20, 8, 8) = aten::feature_dropout(%input.5, %88, %89), scope: Net/Dropout2d[conv2_drop] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:844:0
        * In : %input.5 : Float(64, 20, 8, 8) = aten::_convolution(%input.4, %weight.3, %6, %72, %75, %78, %79, %82, %83, %84, %85, %86), scope: Net/Conv2d[conv2] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/modules/conv.py:340:0
* aten::max_pool2d @ Net
    Detail: %input.7 : Float(64, 20, 4, 4) = aten::max_pool2d(%input.6, %93, %94, %97, %100, %101), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:487:0
        * In : %input.6 : Float(64, 20, 8, 8) = aten::feature_dropout(%input.5, %88, %89), scope: Net/Dropout2d[conv2_drop] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:844:0
* aten::relu @ Net
   Detail: %x : Float(64, 20, 4, 4) = aten::relu(%input.7), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:913:0
        * In : %input.7 : Float(64, 20, 4, 4) = aten::max_pool2d(%input.6, %93, %94, %97, %100, %101), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:487:0
* aten::view @ Net
   Detail: %input.8 : Float(64, 320) = aten::view(%x, %106), scope: Net # ./main.py:30:0
        * In : %x : Float(64, 20, 4, 4) = aten::relu(%input.7), scope: Net # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:913:0
* nn.Linear @ Net/Linear[fc1]
   Detail: %input.9 : Float(64, 50) = aten::addmm(%bias.1, %input.8, %108, %109, %110), scope: Net/Linear[fc1] # /home/nau/.pyenv/versions/anaconda3-2019.03/envs/torch/lib/python3.6/site-packages/torch/nn/functional.py:1369:0
        * In : %bias.1 : Tensor = prim::GetAttr[name="bias"](%8)
        * In : %input.8 : Float(64, 320) = aten::view(%x, %106), scope: Net # ./main.py:30:0
"""


