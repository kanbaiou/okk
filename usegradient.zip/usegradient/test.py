from resnet import ResNet20
import torch

net = ResNet20()

test_input = torch.zeros(10,3,32,32)

