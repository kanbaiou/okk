# Overview

wjittrace is 'wrapper of jittrace'.

Trace information from pytorch jit.trace is difficust to read and reuse.

By using [pytorch-ir](https://github.com/pytorch/pytorch/wiki/PyTorch-IR) API, wjittrace make it more usable.

# How to use

Check sample at main.py.

# pytorch version

v1.2.0 or later

