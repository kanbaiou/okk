from __future__ import print_function
import os
import argparse
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from pprint import pprint
import re

class JITEdge():
    def __init__(self, raw_jitvalue, jitgraph):
        self.jitgraph = jitgraph
        self.raw_jitvalue = raw_jitvalue
    def __str__(self):
        return '%{:<8} | {:<16}\tfrom {:<16}\tto {}'.format(self.id, str(self.dtype + str(self.shape)), str(self.producer), str(self.consumers))
    def __repr__(self):
        return self.__str__()
    @property
    def shape(self):
        type_str = self.raw_jitvalue.type().str()
        s = re.search(r'\w+\((.*)\)', type_str)
        if s:
            shape = [int(re.sub(r'\D', '', dim)) for dim in s.group(1).split(',')]
            return shape
        return []
    @property
    def dtype(self):
        type_str = self.raw_jitvalue.type().str()
        s = re.search(r'(\w+)\(.*\)', type_str)
        if s:
            return s.group(1)
        return type_str
    @property
    def consumers(self):
        consumers = []
        for use in self.raw_jitvalue.uses():
            consumers.append(JITNode(use.user, self.jitgraph))
        return consumers
    @property
    def producer(self):
        return JITNode(self.raw_jitvalue.node(), self.jitgraph)
    @property
    def id(self):
        return self.raw_jitvalue.debugName()

class JITNode():
    def __init__(self, raw_jitnode, jitgraph):
        self.jitgraph = jitgraph
        self.raw_jitnode = raw_jitnode
    def __str__(self):
        return '{} @ {} (class = {})'.format(self.operationname, str(self.pyobjectnames), str(self.pyclassnames))
    def __repr__(self):
        return self.__str__()
    @property
    def operationname(self):
        return self.raw_jitnode.kind()
    @property
    def pyobjectnames(self):
        scope_str = self.raw_jitnode.scopeName()
        s = re.findall(r'\[([^[]+)\]', scope_str)
        if s:
            names = s
        else:
            names = []
        return [''] + list(names) # top level model doesn't have variable name
    @property
    def pyobjectname(self):
        return '.'.join(self.pyobjectnames)
    @property
    def pyobjects(self):
        currentobj = self.jitgraph.pymodel
        objects = [self.jitgraph.pymodel]
        objectnames = self.pyobjectnames
        for objname in objectnames[1:]:
            currentobj = getattr(currentobj, objname)
            objects.append(currentobj)
        return objects
    @property
    def pyobject(self):
        return self.pyobjects[-1]
    @property
    def pyclassnames(self):
        return [n.__class__.__name__ for n in self.pyobjects]
    @property
    def inputs(self):
        inputs = []
        for i in self.raw_jitnode.inputs():
            inputs.append(JITEdge(i, self.jitgraph))
        return inputs
    @property
    def outputs(self):
        outputs = []
        for i in self.raw_jitnode.outputs():
            outputs.append(JITEdge(i, self.jitgraph))
        return outputs

class JITGraph():
    def __init__(self, model, example_input):
        raw_jitoutput = torch.jit.trace(model, example_input)
        self.pymodel = model
        self.raw_jitgraph = raw_jitoutput.graph
    def __str__(self):
        buf = ''
        for node in self.nodes:
            buf += '* {}'.format(node) + os.linesep
            for data in node.inputs:
                buf += '  - In : {}'.format(data) + os.linesep
            for data in node.outputs:
                buf += '  - Out: {}'.format(data) + os.linesep
        return buf
    def __repr__(self):
        return self.__str__()
    @property
    def nodes(self):
        nodes = []
        for jitnode in self.raw_jitgraph.nodes():
            nodes.append(JITNode(jitnode, self))
        return nodes

# def is_maindataflow(node):
#     if re.search(r'%[^0-9]+(\.[0-9]+)?[, ]', str(node)):
#         return True
#     return True

# def operation_of(node):
#     op = node.kind()
#     return op

# def generate_module_graph(model, example_input):
#     output = torch.jit.trace(model, example_input)
#     trace = output.graph
#     # print('--all trace--')
#     # print(trace)
#     for node in trace.nodes():
#         #pprint(dir(node))
#         #print(node.sourceRange())
#         for b in node.blocks():
#             print('Block', b)
#         if is_maindataflow(node):
#             print('* {} @ {}'.format(operation_of(node), node.scopeName()))
#             print('  └ Detail: ' + str(node).rstrip())
#             for i in node.inputs():
#                 if is_maindataflow(i.node()):
#                     # Can be traced recursively
#                     print('\t* In : ' + str(i.node().__str__()).rstrip())
#                     print('\t* In : ' + str(i))
#                     pprint(i.type().kind())
#                     pprint(i.type().str())
#                     pprint(i.debugName())
#                     pprint(str(i.type()))
#                     #pprint(dir(i.type()))
#                 # print(type(i.type().sizes()))
#                 # print(type(i.type().dim()))
#             # Output is same of current node.
#             # for i in node.outputs():
#             #     if is_maindataflow(i.node()):
#             #         print('\t* Out: ' + str(i.node()).rstrip())
#             for i in node.outputs():
#                 #pprint(dir(i))
#                 #print(i.toIValue())
#                 #pprint(dir(i.toIValue()))
#                 #print(i.type().sizes())
#                 for j in i.uses():
#                     # pprint(dir(j.user))
#                     # pprint(dir(j.user))
#                     print('\t* Out: {} ({})'.format(str(j.user).rstrip(), j.offset))
#     return trace

