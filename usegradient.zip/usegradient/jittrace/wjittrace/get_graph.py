import torch
from wjittrace import *
from densenet import DenseNet121
from testnet import TestNet
from utils import *

###  NOTE this sample is not for the simple case , for other network , it may not works

USEFUL_NODES =\
    ['aten::constant_pad_nd','aten::add','aten::cat','aten::view','aten::addmm','aten::_convolution','aten::batch_norm']

SHARING_NODES = ['aten::add','aten::cat']

baseline_net = DenseNet121()
test_input = torch.zeros(10,3,32,32)
fake_graph = JITGraph(baseline_net,test_input)

all_nodes = fake_graph.nodes

useful_node = []
for n in all_nodes[-1:0:-1]:
    if n.operationname in USEFUL_NODES:
        useful_node.append(n) 


main_graph = {}

for n in useful_node:
     next_node =[]
     get_next_useful_node(n,next_node)
     #if n.operationname in  SHARING_NODES:
            # non_duplicate(next_node)
     main_graph[n.raw_jitnode] = [i.raw_jitnode for i in next_node ] 
     main_graph[n.raw_jitnode]  =  list(set(main_graph[n.raw_jitnode]))    ###  if duplicated nodes exist, delete them 



start_node =  list(main_graph.keys())[0]
end_node =   list(main_graph.keys())[-1]

len_list =[]

for  v in main_graph.values():
    len_list.append(len(v)) 

len_list_after_expand = []
expand_graph(main_graph)   ### expand  directional graph to  non-directional graph

for v in main_graph.values():
     len_list_after_expand.append(len(v))

len_list_expand = list(map(lambda x,y :x-y,len_list_after_expand,len_list ))    ## expanded parts

sharing_node =[]

for k in main_graph.keys():
    if len(main_graph[k]) >=3:  ## if connnected with  more tha two nodes
        sharing_node.append(k)

print('sharing_node is ....')
print(sharing_node)   ###  NOTE the node here is  torch._C.nodes  type

reverse_graph(main_graph,len_list)  ##  

one_route =  search_N_route(main_graph,end_node,start_node,1)[0]  ## NOTE in reverse , start node and end node will be reversed

final_route = [end_node] # cerate final_route 

for no in one_route:
        if no in sharing_node:
                final_route.append(no)
final_route.append(start_node)
print('the final_route is ...')
print(final_route)


for i in range(0,len(final_route)-1):
        result = searchGraph(main_graph,final_route[i],final_route[i+1])
        print(len(result))

####  ok al least for densenet , this graph works 

dataflow_depth =[3]  ## initial data is the input images 


for  i in  range(0,len(final_route)-1): ## for every - sharing-node pair (computing block)
        branch_result = searchGraph(main_graph,final_route[i],final_route[i+1])
        conv_list = []   ### used to contain all branch's conv-node
        bn_list   =   []  ### used to  contain all branch's bn-node
        branch_channel_list =[]
        
        for branch in branch_result:   ###  deal with every branch 
                initial_depth = dataflow_depth[-1]   ### initialize the dataflow_depth for every branch
                if i==0:  ### for the first pair , start node should be taken in consideration    follwing part should be included in one module
                        dataflow_for_branch(branch,conv_list,bn_list,branch_channel_list,0,initial_depth)
             
                else:
                        dataflow_for_branch(branch,conv_list,bn_list,branch_channel_list,1,initial_depth)
                       
        if  final_route[i+1].kind() == 'aten::add':  # deal with  final_node
                ###  if the end_node is add 
                ## TODO
                ##  examine whether conv-node is in both two routes
                #    if all conv-node in both two nodes
                #          find block 's output channel  by examing the weight 
                #    else: 
                #         comparing output channel with input channel , and setting the output channel as the maximum one
                if [] not in conv_list:  ## if both two branch have conv layers:
                        for conv in conv_list:
                                if is_pruning_target(conv[-1]):   ## TODO  defining is_pruning_targey
                                    origin_channel = get_pruning_channel(conv[-1])         ## TODO  defining get_pruning_channel
                        for conv in conv_list:
                                if not is_pruning_target(conv[-1]):
                                    set_conv_channel(conv[-1],origin_channel)   ##  TODO set_conv_channel
                else:             set_bn_channel()  ### TODO for bn layer setting the correct channel
                        for  conv  in conv_list:
                                if is_pruning_target(conv_list[-1]):
                                        origin_channel = get_pruning_channel(conv[-1])
                        if origin_channel>= dataflow_depth[-1]:   ### this time is same
                                for conv in conv_list:
                                        set_conv_channel(conv[-1],dataflow_depth[-1])
                        else:  
                                for conv in conv_list:
                                        set_conv_channel(conv[-1],)
                                  
                        
        elif  final_route[i+1].kind() == 'aten:cat': 
                ###  if the end_node is cat
                ### TODO
                ###  add  every branch 's output for the final output
                block_output = sum(branch_channel_list)
                dataflow_depth.append(block_output)
        else:
                block_output = branch_channel_list[0]
                dataflow_depth.append(block_output)

###  finish all flow 