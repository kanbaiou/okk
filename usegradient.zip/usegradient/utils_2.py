import torch
import torch.nn as nn
import numpy as  np
import copy
import matplotlib.pyplot as plt
import torch.nn.init as init


SAVE_LIST =[]
class keep_input(nn.Module):
    """
    this class is used to replace certain layer , when this layer 's all channels is pruned
    
    return the same value as input
    """
    
    def __init__(self):
        super(keep_input, self).__init__()
        

    def forward(self, x):
       
        return x


def is_basic_module(target_module):
    
      indicator=None
      while indicator==None:
         try:
            indicator = next(target_module.named_children())
         except StopIteration:
          indicator='errorhappen'
      if indicator=='errorhappen':# and hasattr(target_module,'weight'):
        return True
      else:
        return False

def updating_shortcut(short_cut,input_channels,output_channels,skip_marked):

    ### making  standard shortcut with   conv1x1-BN-(relu)   structure NOTE if original defining 's shortcut contains a relu should also define a relu here
    ## input_channels  and output_channels is block's input_channels and output_channels
    if is_basic_module(short_cut):
      if skip_marked :
           conv_layer= nn.Conv2d(input_channels,output_channels,1,2,bias=False)   ### if the former layer was skipped , this layer should reduce the FM' size 
           bn_layer = nn.BatchNorm2d(output_channels)
           new_shortcut = nn.Sequential(conv_layer,bn_layer)
      else:
           conv_layer= nn.Conv2d(input_channels,output_channels,1,1,bias=False)   ### if the former layer was skipped , this layer should reduce the 
           bn_layer = nn.BatchNorm2d(output_channels)
           new_shortcut = nn.Sequential(conv_layer,bn_layer)
           
    else: 
        if skip_marked:
           conv_layer= nn.Conv2d(input_channels,output_channels,1,1,bias=False)  ##  if fm size reduce layer was skipped , this skip will not reduce fm' size  
           bn_layer = nn.BatchNorm2d(output_channels)
           new_shortcut = nn.Sequential(conv_layer,bn_layer)
        else:
           conv_layer= nn.Conv2d(input_channels,output_channels,1,2,bias=False)  ##  if fm size reduce layer was skipped , this skip will not reduce fm' size  
           bn_layer = nn.BatchNorm2d(output_channels)
           new_shortcut = nn.Sequential(conv_layer,bn_layer)
    
    
    return new_shortcut 

def get_conv_and_bn(net,r=None):
    module_list,bn_list,conv_list =[],[],[]
    for m in net.modules():
        module_list.append(m)
    for i in range(len(module_list)):
        if r == None:
           if isinstance(module_list[i],nn.Conv2d) and isinstance(module_list[i+1],nn.BatchNorm2d):
               conv_list.append(module_list[i])
               bn_list.append(module_list[i+1])
        else:
                if isinstance(module_list[i],nn.Conv2d) and module_list[i].kernel_size!=r  and isinstance(module_list[i+1],nn.BatchNorm2d):
                      conv_list.append(module_list[i])
                      bn_list.append(module_list[i+1])

    return conv_list,bn_list


def get_conv(net,r=None):
    module_list,conv_list =[],[]
    for m in net.modules():
        module_list.append(m)
    for i in range(len(module_list)):
        if r == None:
           if isinstance(module_list[i],nn.Conv2d):
               conv_list.append(module_list[i])
               
        else:
                if isinstance(module_list[i],nn.Conv2d) and module_list[i].kernel_size!=r :
                      conv_list.append(module_list[i])
                      

    return conv_list


    

def flat(complex_list):
    res = []
    for i in complex_list:
        if isinstance(i,list):
            res.extend(flat(i))
        else:
            res.append(i)
    return res


def get_basic_module(net):
    basic_module=[]
    for m in net.modules():
        if is_basic_module(m):
            basic_module.append(m)
    return basic_module

def from_conv_to_conv(conv_old,input_channel=None,output_channel=None):
    if input_channel != None:
        d_input = input_channel
    else:
        d_input = conv_old.in_channels
    if output_channel != None:
        d_output =output_channel
    else:
        d_output= conv_old.out_channels
    d_kernel_size = conv_old.kernel_size
    d_stride = conv_old.stride
    d_padding = conv_old.padding
    d_dilation = conv_old.dilation
    d_groups = conv_old.groups
    if  type(conv_old.bias) ==  type(None):
        d_bias = False
    else:
        d_bias = True
  
    new_conv = nn.Conv2d(d_input,d_output,d_kernel_size,d_stride,d_padding,d_dilation,d_groups,d_bias)
    return new_conv


def from_linear_to_linear(linear_old,input_features=None,output_features=None):
        if input_features != None:
            d_input = input_features
        else:
            d_input = linear_old.in_features
        if output_features != None:
            d_output =output_features
        else:
            d_output= linear_old.out_features
        if type(linear_old.bias) != type(None):
            d_bias = True
        else:
            d_bias = False
        new_Linear = nn.Linear(d_input,d_output,d_bias) 
        return new_Linear           
        


    
def init_params(net):
    '''Init layer parameters.'''
    for m in net.modules():
        if isinstance(m, nn.Conv2d):
            init.kaiming_normal_(m.weight, mode='fan_out')
        #    if m.bias:
         #       init.constant(m.bias, 0)   NOTE for conv2d no bias to be setted
        elif isinstance(m, nn.BatchNorm2d):
            init.constant_(m.weight, 1.0)
            init.constant_(m.bias, 0)
        elif isinstance(m, nn.Linear):
            init.normal_(m.weight, std=1e-3)
            #if m.bias:   NOTE for linear layer should initialize the bias as 0
            init.constant_(m.bias, 0)

def get_all_params(net):
    conv_list ,bn_list = get_conv_and_bn(net)
    num_params = 0
    for l in conv_list:
        num_params+=torch.numel(l.weight.data)
    for l in bn_list:
        num_params+=torch.numel(l.weight.data)*2    # also contains bias  num(bias) = number(gamma)
    
    return num_params


def get_all_flops(net,test_input):
     
     SAVE_LIST.clear()    
     cfg_saver=[]
     handle_saver=[]
     conv_list =[]
     flops=0
     for m in net.modules():
         if isinstance(m,nn.Conv2d):
              handle_saver.append(m.register_forward_hook(save_fm))
              conv_list.append(m)
      
     _= net(test_input)
     
 
     for h in handle_saver:
         h.remove()
     
     
     for i in range(len(conv_list)):
        flops+=torch.numel(conv_list[i].weight.data)*SAVE_LIST[i]
            
     return flops
    


def  save_fm(module,input,output):      
      
      """
      forward hook, will save the output featuremap's area  to compute flops cost
      """
      #print(output.shape)
      SAVE_LIST.append(output.shape[2]*output.shape[3])   


def get_module_name(net,target_module):
     name = 'unfound'
     for p in net.named_modules():
        if p[1] == target_module:
            name = p[0]
     if name =='unfound':
          print(target_module)         
     return name


def  replace_module(net,name,new_module):
      name_list=[]
      for n in name.split('.'):
          try:
              name_ = int(n)
          except ValueError:
              name_ = n
          name_list.append(name_)
      
      if len(name_list) ==1:
       
           assert name_list[0]!='unfound'
           setattr(net,name_list[0],new_module)
      
      else:

        for i in range(len(name_list)-1):
            if i ==0:
              if isinstance(name_list[i],str):
                   mid_state=getattr(net,name_list[i])
              elif isinstance(name_list[i],int):
                   mid_state = net[name_list[i]]
            else:
              if isinstance(name_list[i],str):
                   mid_state = getattr(mid_state,name_list[i])
              elif isinstance(name_list[i],int):
                   mid_state=mid_state[name_list[i]]
      
        if isinstance(name_list[-1],str):
             setattr(mid_state,name_list[-1],new_module)
        elif isinstance(name_list[-1],int):
             mid_state[name_list[-1]] = new_module    
      
    
            
def   from_old_to_new(net,old_module,new_module):

       name = get_module_name(net,old_module)
       replace_module(net,name,new_module) 


  

def get_skip_mark(cfg,layer_length,block_length):
    # layer_length, small block,  e.g. 2
    ## block_length , big block -> fm size in which is same    e.g. 6
    ## output -> layer's index  which need to change stride from 1 to2      (1)
    #                    block' s index which need to change stride from 1 to 2     (2)
    #                   block's inde which need to change  stride from 2 to 1   ( only at fm size change block)    (3)
    # 
    skip_mark = int(((len(cfg)-1)/layer_length))*[False]
    layer_mark = [False] * len(cfg)
    for  i in range(len(cfg)):
        if (i-1)%block_length ==0 and  i!=1:  ## first layer
            if cfg[i]==0 and cfg[i+1]==0:  ## this small block was skipped
               skip_mark[int((i-1)/layer_length)] = True   ## mark (3)
               for j in range((i-1),1,-2):
     
                   if  cfg[j]!=0 :
                       skip_mark[int((j-2)/layer_length)] = True
                       layer_mark[j] = True
                       break
                   elif cfg[j-1] !=0:
                       skip_mark[int((j-1)/layer_length)] =True
                       layer_mark[j-1] = True
                       break
            elif cfg[i]==0 and cfg[i+1]!=0:   ### just change another layer 's stride
                       layer_mark[i+1] = True

    return skip_mark,layer_mark



        

      
